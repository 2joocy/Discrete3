import OperationHandler from './OperationHandler';

let op = new OperationHandler();

console.log(op.membership(-9,[1,2,3,4,5,7]));
console.log(op.difference([1,2,3,4],[2,3,4,5]));