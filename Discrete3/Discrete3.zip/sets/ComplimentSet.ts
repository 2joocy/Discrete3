export default class ComplimentSet{

    constructor(firstSet: number[], resultSet: number[]){
        this.firstSet= firstSet;
        this.resultSet= resultSet;
    }

    private firstSet: number[];
    private resultSet: number[];

}