export default class IntersectionSet{

    constructor(firstSet: number[], secondSet: number[], resultSet: number[]){
        this.firstSet= firstSet;
        this.secondSet= secondSet;
        this.resultSet= resultSet;
    }

    private firstSet: number[];
    private secondSet: number[];
    private resultSet: number[];

}